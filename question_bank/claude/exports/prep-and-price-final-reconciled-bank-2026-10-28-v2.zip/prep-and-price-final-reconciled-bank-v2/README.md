# Prep & Price final reconciled question bank — package v2 (2026-10-28)

**AI-generated drafts. No record is human-approved. Difficulty is provisional. Nothing has been imported, deployed or published.**

## Provenance

| | |
|---|---|
| Repository | `bemrick2/CollegePrep` |
| Bank branch | `ccr-78c91309-anlh8e` |
| Bank content commit | `fd098654de6c422d80a934909683bb8228fc85fd` (final whole-bank audit) |
| v1 package commit | `04ed267f286b488953ae2ef5933d618b363529f7` (ZIP sha256 `6a828379f042e14433e4263a5fa31ff8c0607d506c2a73f83063d87fb5490ac2`) |
| Validator | `web/scripts/validateQuestionImport.ts` at `origin/main` `43d4c7269c69172e6d570e51d3d1ab1ab0f0d450` |
| Built by | `question_bank/claude/tools/build_import_package.py` plus the steps in `validation/import-validation-report.txt` |

Original IDs are unchanged everywhere. Each record's `provenance` (source bank, baseline membership, batch, draft candidate, author, overlay, superseded_by) and `content_hash` are as in v1. Import lines use `import_id` = lowercased original ID.

## What v2 adds to v1

The v1 package files are included byte-for-byte (they still verify against `manifest.json`). v2 adds:

| Path | Contents |
|---|---|
| `import/v1/*.jsonl` | `question_import/v1` lines for the 3,831 reviewed Claude drafts, exactly as the workstream wrote them |
| `import/v2/*.jsonl` | The same lines in `question_import/v2` (current contract on `main`) |
| `import/excluded-from-import.json` | 15 lines in the branch's own import files that the reconciled bank does not count |
| `import/chatgpt-contract-gaps.json` | The 1,620 reviewed ChatGPT drafts and the contract fields each lacks (why they have no import lines) |
| `import/crosscheck.json` | Every import line compared with its reconciled record (stem, choices, key, passage): 3,831 of 3,831 match |
| `validation/` | Validator output per file, a combined cross-section run, and a negative control proving the validator rejects bad lines |
| `review-evidence/` | Current-version evidence for all 5,451 reviewed drafts: Claude review files and math recomputation scripts, ChatGPT fresh blind-review files, the user-supplied baseline screening ZIP (checksum verified), and `evidence-index.json` mapping each record to its evidence |
| `counts-by-section.csv` / `.json` | Final counts by section and status |
| `unresolved-issues.md` | Everything still open, including four issues found in this pass |
| `manifest-v2.json` | SHA-256 of every file in this package |

## Final counts

| Section | Reviewed drafts | Claude | ChatGPT | Pending | Hold | Reserved dup. | Retired | Import lines |
|---|---|---|---|---|---|---|---|---|
| SAT Math | 1,000 | 1,000 | 0 | 0 | 0 | 31 | 0 | 1,000 |
| SAT Reading and Writing | 1,008 | 695 | 313 | 0 | 2 | 22 | 15 | 695 |
| ACT English | 1,002 | 691 | 311 | 0 | 0 | 34 | 11 | 691 |
| ACT Reading | 1,003 | 686 | 317 | 0 | 0 | 39 | 1 | 686 |
| ACT Math (paused) | 1,438 | 759 | 679 | 178 | 16 | 43 | 0 | 759 |
| **Total** | **5,451** | 3,831 | 1,620 | 178 | 18 | 169 | 27 | 3,831 |

5,843 reconciled records; 1,120 passages used by reviewed drafts (embedded in each record); 249 Claude candidates never banked (with reasons, in `held-and-rejected.json`). No separate asset files are required: tables are inline in stems, and five ACT Math items carry optional text figure descriptions.

## Validation results

`main`'s validator: **0 problems** on all five v1 files, all five v2 files, and all 3,831 v2 lines validated together. Negative control: 4 of 4 deliberately broken lines rejected. A pass only means an item may **start** editorial stage 3.
