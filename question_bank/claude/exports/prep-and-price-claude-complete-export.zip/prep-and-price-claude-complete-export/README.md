# Prep & Price: complete export of Claude's question bank

Generated 2026-10-27T09:42:34+00:00 from `bemrick2/CollegePrep`, branch `ccr-78c91309-anlh8e`, commit `4f36563b00fc0fac5aeacb370ff7ead66d28194c`
(path `question_bank/claude/`). Producer: `source/tools/export_complete.py`.

**Every item is an AI-generated draft.** No human has reviewed any item. No rights or legal review has occurred.
Nothing here has been imported, deployed or published.

## Exact counts

Accepted and live: **2238** items.

| Exam / section | Accepted (live) | Retired after acceptance | REVISE | REJECT | Withdrawn before review | Incomplete drafts |
|---|---|---|---|---|---|---|
| ACT Math | 774 | 21 | 3 | 2 | 2 | 0 |
| ACT English | 318 | 34 | 10 | 0 | 2 | 0 |
| ACT Reading | 316 | 35 | 28 | 0 | 12 | 0 |
| SAT Reading and Writing | 312 | 27 | 20 | 1 | 4 | 0 |
| SAT Math | 518 | 27 | 2 | 0 | 27 | 0 |

- Unique passages used by accepted items: ACT English 35, ACT Reading 42, SAT Reading and Writing 339 (each SAT Reading and Writing item has its own short passage). ACT Math and SAT Math have none.
- Quarantined or incomplete records in total: 257. Of these, 39 were later fixed, resubmitted under a new candidate number and accepted. The accepted version is in `questions-full.json`, and the earlier version stays in `quarantined-and-incomplete.json` with a `later_resolution` link. They are not counted twice.
- Incomplete drafts (drafted but never reviewed): 0.

## Files

| File | Contents |
|---|---|
| `questions-full.json` | The 2238 accepted, live items, each with its full record. This covers: source (bank file, batch, draft candidate, draft and review files, branch); exam, section, category, skill, subskill and modeling flag; the full passage and stable `passage_id`; underlined-span number (ACT English); figure spec; stem and choices; calculator policy; key, explanation, distractor explanations and trap types; hints, strategy and remember line; the cited evidence quote (verbal); provisional difficulty; author, origin and generation date; content version; recorded license and rights status; review status; and the validation summary. |
| `questions-blind.json` | The same 2238 items with the same IDs. It contains only student-facing material: exam, section, category, skill, passage, underlined-span number, figure spec, stem, choices, calculator policy and time. It has no keys, explanations, hints, strategies, evidence quotes, subskill labels or validation data. |
| `answer-key-and-review.json` | For every accepted record, matched by ID: key, explanation and distractor reasoning, plus the review history separated into author self-review, programmatic verification, separate blind solvers (every round), whole-bank AI raters and human review (none). It includes the 144 retired records, marked `live: false`. |
| `quarantined-and-incomplete.json` | Retired, REVISE, REJECT and withdrawn candidates, each with its reason, the item as drafted, any blind-solver records, any later resubmission and its outcome, and a check for conflicts between copies. |
| `manifest.json` | Counts, checks, the near-duplicate report, the sources inspected, missing sources and SHA-256 checksums of every file. |
| `quality-screening-checklist.md` | A checklist for screening the combined (Claude + ChatGPT) bank. |
| `import-validation-report.txt` | Output of the repository's own import validator on `source/exports/import/*.jsonl`. |
| `contract/` | `QUESTION_IMPORT_CONTRACT.md` (the `question_import/v1` contract) and `QUESTION_REVIEW_WORKFLOW.md`. |
| `source/` | Unmodified copies of the workstream's source files. `banks/` holds the append-only accepted banks, including retired records. `drafts/` holds every candidate as written. `reviews/` holds the per-batch reconciliation and every blind-solver file, including earlier rounds. `checks/` holds the math recomputation scripts. `calibration/` holds the whole-bank AI ratings. `audits/` holds the retirement, overlap and pending-revision logs. `exports/import/*.jsonl` holds the contract-format files. Also included: `progress.json`, `WORKER.md`, `README.md` and the tools. |

There are no binary assets. 5 math items carry a text `figure` description; every item is meant to be solvable from its text, and figures need human checking before production. Tables are written inline in the stem or passage, with `|` separators.

## What the validation evidence does and does not mean

- **Author self-review.** The checklist was written by the same model that wrote the item. It is not independent.
- **Programmatic verification.** For **Math**, a script in `checks/` recomputes the answer from the stem's numbers. The author wrote these scripts, but they never read the key, and the computed answer matches the key for every accepted item. For **verbal** items there is **no** programmatic solve. The checks confirm only the structure, that the cited evidence quote appears word for word in the passage, and a near-duplicate screen. In the source records, the verbal `computed_answer` field only records that those checks passed.
- **Separate blind solvers.** These are separate AI agents of the same model family, each working in its own context from an answer-free packet: one per Math batch and two per verbal batch. An item was accepted only when every solver matched the key and no solver raised a non-minor flag. These solvers are not human and not truly independent of the author model.
- **Whole-bank AI raters.** These are separate AI agents that re-solved and re-rated whole banks at the 100-item audits. Items where a rater disagreed with the key were adjudicated at audits, with notes in `source/progress.json` (`calibration_notes` and `audits`). **The author adjudicated these, so they still need human review.**
- **Human review.** There has been none. `review_status` is `ai_reviewed_pending_human` and `human_review` is null on every record.

## Difficulty is provisional

`difficulty.author_label` is the author's estimate. `difficulty.ai_calibrated_label` is the median of the AI solver and rater ratings, which estimate the share of typical students who would answer correctly. Neither comes from student responses.

| Exam / section | Author labels | AI-calibrated labels |
|---|---|---|
| ACT Math | {'easy': 194, 'medium': 361, 'hard': 219} | {'easy': 263, 'medium': 417, 'hard': 94} |
| ACT English | {'easy': 132, 'medium': 164, 'hard': 22} | {'easy': 122, 'medium': 102, 'hard': 4, None: 90} |
| ACT Reading | {'medium': 170, 'easy': 114, 'hard': 32} | {'easy': 121, 'medium': 85, None: 110} |
| SAT Reading and Writing | {'easy': 79, 'medium': 202, 'hard': 31} | {'easy': 133, 'medium': 106, 'hard': 8, None: 65} |
| SAT Math | {'easy': 82, 'medium': 386, 'hard': 50} | {'easy': 132, 'medium': 325, 'hard': 42, None: 19} |

The independent raters consistently judge verbal items, and many items labelled hard, as easier than the author labels say. **ACT Reading has no item that the raters judge hard.**

## Known issues and flags

1. **Near-duplicates.** The manifest's `duplicate_report_within_this_bank` lists 73 pairs within this bank that share at least 70% of the words in stem and choices. These are lexical candidates for a human to compare, not confirmed duplicates. Concept repeats found at audits were already retired: 144 items, listed in `source/audits/`. Template-level repeats with changed numbers may remain, because the bank grew from one model's habits. The duplicate screen against ChatGPT's banks has not been done.
2. **Rights.** `license_recorded` is `original-owned` on every item. The pipeline set that value; no legal review backs it. Some verbal passages state real-world facts or name real people and studies, which the blind solvers checked only from memory. SAT passage `CLD-P-SAT-RW-000259` (item `CLD-SAT-RW-000250`) quotes two lines of Christina Rossetti's 1872 poem "Who Has Seen the Wind?". The poem is in the public domain, but the recorded license does not say so.
3. **Earlier passage text.** Some passages were corrected after a blind solve; each such draft's `revision_log` records it. In those cases the draft file was overwritten, so the earlier passage text is not preserved. The round-N solver reviews that prompted each correction are in `source/reviews/` as `*.round*.blind*.json`.
4. **Answer-key letter balance.** Keys are spread across A–D, but at times the spread was uneven. The 600-item audit, for example, found Math keys leaning toward B and C. Later batches weighted keys toward A and D to compensate.
5. **SAT stems referring to an underlined sentence.** These name the sentence in the stem (for example, "The underlined sentence is ...") because the record format has no underline markup for SAT. Rendering would need to add the underline.

## Relation to the repository's import contract

`source/exports/import/*.jsonl` holds the same live items in the repository's `question_import/v1` format (`contract/QUESTION_IMPORT_CONTRACT.md`). Each line has `status: draft`, `origin: ai_drafted`, `author: ai:claude` and `import_id` = lowercased ID. The repository's validator (`web/scripts/validateQuestionImport.ts`) reports **0 problems** for all five files (`import-validation-report.txt`). As the contract states, passing the validator only makes an item eligible to **start** human editorial stage 3; it is not approval. `questions-full.json` and the other package files are **not** in contract format and have not been validated against it.

## Sources and coverage

See `manifest.json` → `sources_inspected` and `missing_or_inaccessible_sources`. In short:
- The complete source of truth is `question_bank/claude/` on branch `ccr-78c91309-anlh8e`.
- `main` contains no Claude items, and no other branches, worktrees or sessions are accessible from here.
- No question was reconstructed from memory, and none was generated for this export.
