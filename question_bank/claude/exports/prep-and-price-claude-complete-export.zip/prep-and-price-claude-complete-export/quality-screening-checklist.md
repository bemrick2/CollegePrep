# Quality-screening checklist for the combined bank (Claude + ChatGPT)

This checklist prepares the combined screen. **The combined bank has not been screened.** This export contains only Claude's items.

Record one outcome per question: **PASS**, **REVISE** (fixable, with the specific fix), **QUARANTINE** (needs a decision or more evidence) or **REJECT** (fundamentally flawed or a duplicate). Give a question-level reason for every outcome other than PASS.

## 1. Inventory and identity
- [ ] Load every contributing bank; confirm counts match each bank's manifest.
- [ ] Check ID uniqueness across banks (Claude IDs start with `CLD-`); never re-key silently.
- [ ] Every passage reference resolves; passage sets are complete; no orphan passages.
- [ ] No item reaches students: keep all items `draft` until human stages 3–8 and the rights gate pass.

## 2. Duplicates (across ALL banks, not just within one)
- [ ] Exact duplicates: identical stem + choices (after normalizing whitespace, Unicode minus signs, superscripts and `^`).
- [ ] Near duplicates: high token overlap of stem + choices (Claude's manifest lists pairs within its own bank at ≥ 0.70 Jaccard).
- [ ] **Template duplicates**: same underlying problem with changed numbers, names or context (e.g., "car worth $X loses Y% a year", "units digit of 7^n", "circle tangent to both axes through (a, b)"). Compare by subskill/skill tag *and* solution method, not wording alone.
- [ ] Same passage topic or the same real-world study used in two banks.
- [ ] Two items on the same passage that test the same idea, or where one item's choices give away another's answer.
- [ ] Keep the better item of each duplicate set; record the others as REJECT (duplicate of ID).

## 3. Blind solving (without author keys)
- [ ] A solver who has not seen any key answers every item from student-facing text only (`questions-blind.json` for Claude).
- [ ] Any disagreement with the key → QUARANTINE until adjudicated by a human; never let the author adjudicate alone.
- [ ] Record the solver's confidence and estimated difficulty.

## 4. Correctness and answer quality
- [ ] Exactly one defensible correct answer; no "also arguably correct" choice.
- [ ] Distractors are plausible, distinct, each tied to a real error, and none is accidentally correct.
- [ ] Math: arithmetic, domains and restrictions (division by zero, square roots, logs), units and rounding instructions, exact vs. approximate answers, figure/table consistency, and "not drawn to scale" where relevant.
- [ ] Verbal: the answer is supported by the passage text (cite the line); no outside knowledge needed; English edit spans are unambiguous and "NO CHANGE" is handled correctly; punctuation items have one standard answer.
- [ ] Factual claims in passages are accurate (dates, quantities, named studies), or the passage is clearly fictional.
- [ ] No answer cue: key not systematically longest, not the only choice in a different style, not echoed by the stem.

## 5. Alignment, clarity and difficulty
- [ ] Exam/section alignment (ACT Math, English, Reading; SAT Reading and Writing; SAT Math) and correct category/skill tags.
- [ ] Item format matches the exam (4 choices for ACT enhanced and SAT; SAT one-passage-one-question).
- [ ] Clear, grade-appropriate wording; calculator policy stated where relevant.
- [ ] Difficulty labels marked **provisional**; replace with student-response calibration when available. Note where AI raters and author labels disagree.

## 6. Originality, provenance and rights
- [ ] Origin and author recorded (`ai:claude` / ChatGPT equivalent); every reviewer differs from the author.
- [ ] No official ACT or College Board material, and no close paraphrase of commercial prep items.
- [ ] Quoted text (e.g., public-domain poetry) is identified and licensed correctly.
- [ ] License field is verified by a person before any item is served (`original-owned` was set by a pipeline, not reviewed).

## 7. Outcome record (per question)
| Field | Content |
|---|---|
| id | Original ID |
| bank | Contributing bank |
| outcome | PASS / REVISE / QUARANTINE / REJECT |
| reason | Specific, question-level |
| duplicate_of | ID, if any |
| reviewer | Named person or tool; never the author model alone |
| evidence | Blind-solve result, check performed, source consulted |
