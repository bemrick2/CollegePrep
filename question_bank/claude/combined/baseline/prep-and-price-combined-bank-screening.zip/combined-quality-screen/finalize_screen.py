import pathlib,json,re,collections,csv,hashlib,zipfile,shutil
R=pathlib.Path('/workspace/scratch/ba24631dbeef');P=R/'combined-quality-screen';CL=R/'claude_export/prep-and-price-claude-complete-export'
def read(p):return json.loads(p.read_text())
def save(n,d):(P/n).write_text(json.dumps(d,ensure_ascii=False,indent=2))
rows=read(P/'combined-bank-preserved.json');by={q['id']:q for q in rows};issues=read(P/'issues-initial.json')
def flag(id,code,detail,severity='hold'):issues.setdefault(id,[]).append({'code':code,'detail':detail,'severity':severity})
def pairkey(a,b):return '|'.join(sorted([a,b]))
decisions={}
def decide(a,b,decision,reason,hold=None):
 decisions[pairkey(a,b)]={'a':a,'b':b,'decision':decision,'reason':reason,'held_variant':hold}
 if hold:flag(hold,'TEMPLATE_VARIANT_RESERVED',f'{reason} Retained comparison item: '+(b if hold==a else a),'exclude')
def distinct(a,b,why):decide(a,b,'retain_distinct',why)
def duplicate(a,b,why,hold=None):decide(a,b,'reserve_redundant_variant',why,hold or b)
duplicate('CLD-ACT-M-000039','CLD-ACT-M-000463','Same fraction-between-two-bounds task; only bounds and distractors change.')
distinct('PP-MATH-000021','PP-MATH-000045','Complex multiplication versus complex division requiring conjugate rationalization.')
duplicate('PP-MATH-000031','CLD-ACT-M-000060','Same negative rational exponent of a perfect integer power.')
distinct('PP-MATH-000055','PP-MATH-000321','Scientific-notation division versus addition requiring exponent alignment.')
duplicate('PP-MATH-000492','CLD-ACT-M-000662','Same two-constraint first-quadrant linear-programming vertex maximization template.')
duplicate('CLD-ACT-M-000010','CLD-ACT-M-000695','Same quadratic root-sum task, directly applying -b/a.')
duplicate('PP-MATH-000554','CLD-ACT-M-000112','Same two-branch quadratic/linear piecewise inverse-image counting template.')
distinct('CLD-ACT-M-000353','CLD-ACT-M-000423','One decimal percent versus two successive percentages; different error mechanisms.')
distinct('CLD-ACT-E-000244','CLD-ACT-E-000252','Distinct targets in the same passage: semicolon joining clauses versus colon introducing an explanation.')
distinct('CLD-ACT-M-000080','CLD-ACT-M-000528','Both linear, but variables on both sides versus negative distribution and one-side isolation; retain practice variants.')
distinct('PP-MATH-000095','CLD-ACT-M-000083','Range on a closed interval; vertex form supplied versus completing the square from standard form.')
duplicate('PP-MATH-000113','CLD-ACT-M-000042','Same average-rate-of-change task for x²-3x plus an optional constant on specified endpoints.')
duplicate('PP-MATH-000131','CLD-ACT-M-000726','Same periodic-remainder large-integer-power template; retain one representative for coverage counting.')
duplicate('CLD-ACT-M-000080','CLD-ACT-M-000569','Same variables-on-both-sides linear isolation; 569 offers less variety than the distributed representative.')
distinct('PP-MATH-000362','PP-MATH-000672','Shifted roots versus squared roots; different transformations of the root-sum and product.')
distinct('PP-MATH-000011','CLD-ACT-M-000488','Linear equation versus factoring exponential terms; lexical similarity is misleading.')
duplicate('PP-MATH-000321','CLD-ACT-M-000493','Same addition of two unequal-power scientific-notation terms.')
distinct('CLD-ACT-M-000608','CLD-ACT-M-000622','Right triangle versus trapezoidal quadrilateral; different shape decomposition.')
distinct('CLD-ACT-M-000199','CLD-ACT-M-000247','Solve a system for x versus obtain a requested linear combination by adding the equations.')
distinct('PP-MATH-000052','CLD-ACT-M-000617','Exterior angle supplied versus interior angle supplied; retain the supplementary-angle step.')
distinct('CLD-ACT-M-000573','CLD-ACT-M-000682','Conjugate product plus i² versus binomial square with an imaginary result.')
distinct('CLD-ACT-M-000411','CLD-ACT-M-000683','Degrees versus radians and different quadrants; retain distinct trigonometry practice.')
distinct('CLD-ACT-M-000629','CLD-ACT-M-000788','Single reciprocal proportion versus sum of reciprocal terms; retain practice variants.')
distinct('CLD-ACT-M-000031','CLD-ACT-M-000162','Squaring with extraneous-root rejection versus two-thirds power with two valid signs.')
duplicate('PP-MATH-000271','CLD-ACT-M-000343','Identical three quantities 2³⁰, 3²⁰, 5¹⁰ and the same ordering task; rewording and choice rearrangement add no new item.')
duplicate('PP-MATH-000177','CLD-ACT-M-000753','Same telescoping sum of 1/[n(n+1)], with only the final index changed.')
duplicate('CLD-ACT-M-000121','CLD-ACT-M-000694','Same sinusoid-minimum task using cosine range [-1,1]; alternate coefficients reserved.')
distinct('CLD-ACT-M-000247','CLD-ACT-M-000532','Sum of equations directly yields requested combination versus solving the system before subtracting variables.')
distinct('PP-MATH-000035','PP-MATH-000127','One radical equals x versus sum of two radicals; different isolation/squaring burden.')
distinct('CLD-ACT-M-000500','CLD-ACT-M-000569','Simple one-side equation versus both-side variable equation. 569 is separately reserved relative to 080.')
distinct('CLD-ACT-E-000147','CLD-ACT-E-000153','Independent clause comma splice versus a detached appositive fragment at a different target.')
distinct('CLD-ACT-E-000218','CLD-ACT-E-000221','Paired nonessential-clause punctuation versus direct-object list punctuation at distinct targets.')
duplicate('PP-MATH-000344','CLD-ACT-M-000193','Same labeled trapezoid with bases 6 and 15 and intersection of diagonals; only the diagonal length is scaled.')
distinct('PP-MATH-000218','PP-MATH-000224','Isosceles-altitude bisection versus scalene-triangle area/altitude; different geometric constraints.')
distinct('PP-MATH-000055','CLD-ACT-M-000493','Scientific notation division versus addition; 493 is separately reserved relative to 321.')
distinct('CLD-ACT-M-000493','CLD-ACT-M-000676','Add scientific-notation terms versus convert a decimal to scientific notation.')
distinct('CLD-ACT-M-000081','CLD-ACT-M-000162','Quadratic substitution in an exponential versus fractional power with sign branches.')
duplicate('PP-MATH-000016','CLD-ACT-M-000678','Same two-point slope task; changed coordinates give the same slope -2.')
distinct('CLD-ACT-M-000213','CLD-ACT-M-000721','Combine like radicals versus rationalize a radical denominator.')
distinct('CLD-ACT-M-000528','CLD-ACT-M-000569','Negative distribution versus both-side variables; 569 separately reserved relative to 080.')
distinct('PP-MATH-000128','CLD-ACT-M-000451','Identify a function versus identify the exception; retain contrasting logical-direction practice.')
distinct('CLD-ACT-M-000014','CLD-ACT-M-000747','Diameter endpoints require midpoint/distance versus center and axis tangency.')
distinct('PP-MATH-000302','CLD-ACT-M-000704','Remainder modulo a quadratic versus polynomial quotient by a linear factor.')
distinct('PP-MATH-000173','PP-MATH-000583','Reflected-argument coupled functional equation versus iterated translation identity.')
distinct('CLD-ACT-M-000199','CLD-ACT-M-000532','Eliminate to find one variable versus solve for a difference; different requested operations.')
distinct('CLD-ACT-M-000185','CLD-ACT-M-000608','General non-axis-aligned triangle determinant versus directly visible perpendicular legs.')
distinct('PP-MATH-000287','PP-MATH-000680','Repeated-factor equation with a potentially lost root versus symmetric quartic grouping.')
distinct('CLD-ACT-M-000009','CLD-ACT-M-000119','Complex multiplication versus division/conjugate rationalization.')

# Incorporate the producer's 53 lexical flags. Distinct English edit targets are not duplicate items.
manifest=read(CL/'manifest.json')
for p in manifest['checks']['duplicate_report_within_this_bank']:
 a,b=p['ids'];key=pairkey(a,b)
 if key in decisions:continue
 qa,qb=by[a],by[b]
 if qa['section']=='English':
  assert qa['raw']['underlined_span_number']!=qb['raw']['underlined_span_number'] or qa['passage_id']!=qb['passage_id']
  distinct(a,b,'Different underlined edit targets and sentence contexts; generic question wording/NO CHANGE inflates lexical overlap. No evidence of identical student-facing task.')
 else:
  distinct(a,b,'Expression/operation review: distinct mathematical tasks despite generic stem/choice vocabulary. Retain; this does not establish all-bank absence of lower-similarity concept repeats.')

for pair in read(P/'similarity-candidates.json'):
 assert pairkey(pair['a'],pair['b']) in decisions, pair

# Structural/content defects found by direct insertion review, not inherited from the producer.
for id in ['CLD-SAT-RW-000011','CLD-SAT-RW-000034','CLD-SAT-RW-000043','CLD-SAT-RW-000058','CLD-SAT-RW-000230']:
 q=by[id];flag(id,'NO_VALID_LITERAL_INSERTION','Every choice repeats the word already before the blank. Literal insertion makes all options defective. Proposed repair: remove that preceding repeated word from passage, preserve the choices/key, then re-review the repaired current version.')
for q in rows:
 if q['raw'].get('standard_exam_suitability')=='held_pending_blueprint_review':flag(q['id'],'BLUEPRINT_SUITABILITY_HOLD','Existing source explicitly holds this item pending ACT blueprint review.')
 if q['exam']=='SAT' and q['word_count']<25:flag(q['id'],'SAT_SHORT_DRILL','Passage is below the official published 25–150 word range. Retain only as a short skill drill pending exam-representativeness review.','warning')
 if q['exam']=='SAT' and q['word_count']>150:flag(q['id'],'SAT_LONG_TEXT','Text exceeds official published 150-word upper range; review passage pairing/notes representation.','warning')

# Targeted answers independently checked in this screening pass. Not a bank-wide blind solve.
fresh={
 'CLD-ACT-M-000130':{'answer':'A','reason':'Set C=9C/5+32; (-4/5)C=32 gives C=-40. The other three values fail direct substitution.','result':'key_confirmed; inherited disagreement resolved mathematically'},
 'CLD-ACT-M-000136':{'answer':'B','reason':'Predicted score=2.4×5+31=43; actual minus predicted=50-43=7.','result':'key_confirmed; inherited disagreement resolved mathematically'},
 'CLD-SAT-RW-000100':{'answer':'A','reason':'Restrictive title after the previous statement that Carson wrote several books favors A; the historical comma/appositive dispute is retained for editorial review rather than silently cleared.','result':'editorial_hold'},
 'PP-C-VERBAL-000089':{'answer':'B','reason':'Circumscribed means restricted the subject range; the bridge-only essays define that restriction.'},
 'PP-C-VERBAL-000100':{'answer':'D','reason':'Unknown nonresponse prevents determining the population late-delivery proportion.'},
 'PP-C-VERBAL-000116':{'answer':'C','reason':'A fixed scanner artifact stays on the image side while sheet features reverse; other choices either support a sheet mark or are irrelevant. Strong cueing makes the hard label questionable.'},
 'PP-C-VERBAL-000150':{'answer':'A','reason':'Whoever is subject of arrives and signs within the nominal clause; the whole clause is object of to.'},
 'PP-VERBAL-20261023-N-012':{'answer':'C','reason':'Students already struggling self-select into hint use, confounding the observed association.'},
 'CLD-SAT-RW-000021':{'answer':'B','reason':'Inverted subject is singular a set; completed past-tense context selects was.'},
 'CLD-SAT-RW-000027':{'answer':'C','reason':'If young birds taught by city adults in quiet surroundings do not reproduce city pitch, learning from those adults alone fails to explain the pattern.'},
 'CLD-SAT-RW-000057':{'answer':'A','reason':'Overt means explicit; withholding themes makes later work less overt.'},
 'CLD-SAT-RW-000060':{'answer':'C','reason':'Compatible claims after clarification eliminate the supposed dispute: dissolved, rather than settling it by choosing a winning position.'},
 'CLD-SAT-RW-000066':{'answer':'A','reason':'Date/sender-only catalog lacks descriptive detail: skeletal. Exhaustive conflicts with missing content descriptions.'},
 'CLD-SAT-RW-000068':{'answer':'A','reason':'Prior employment predicts an overly admiring biography (hagiography), contrasted with severe criticism.'},
 'CLD-SAT-RW-000087':{'answer':'C','reason':'Page-long wandering sentences with digressions are discursive.'},
 'CLD-SAT-RW-000099':{'answer':'C','reason':'The committee selected whom; objective relative pronoun required.'},
 'CLD-SAT-RW-000118':{'answer':'D','reason':'Tested and replaced are predicates sharing the subject; and joins them without a semicolon/comma splice.'},
 'PP-B-VERBAL-000173':{'answer':'D','reason':'Relative clause subject that requires finite auxiliary had; it had duplicates that subject.'},
 'PP-VERBAL-20261023-O-013':{'answer':'A','reason':'Mood-grouped chapters spanning journey stages directly demonstrate mood rather than chronological organization.'},
 'PP-VERBAL-20261022-H-007':{'answer':'C','reason':'Two independent clauses with parallel in-the-first/in-the-second structure require an adequate boundary; semicolon alone supplies it.'},
 'PP-C-VERBAL-000048':{'answer':'B','reason':'Me is object of between, parallel to coordinator.'},
 'PP-VERBAL-20261022-E-017':{'answer':'D','reason':'Each is singular; serves is the matching finite verb.'},
 'PP-VERBAL-20261022-H-004':{'answer':'A','reason':'Require someone to submit is the correct complement pattern.'},
 'CLD-SAT-RW-000079':{'answer':'A','reason':'Alone supports solitary and every window brightens supports essential public service.'},
 'PP-C-VERBAL-000083':{'answer':'A','reason':'Succeeded in takes the gerund explaining.'},
 'PP-VERBAL-20261023-N-014':{'answer':'B','reason':'The nonessential relative clause begins with comma+which and closes before will.'},
 'CLD-SAT-RW-000217':{'answer':'A','reason':'Clearing, repairing, planting form the parallel gerund list.'},
 'PP-B-VERBAL-000206':{'answer':'B','reason':'Exactly as tall as requires the positive adjective, not comparative/superlative.'},
 'PP-B-VERBAL-000149':{'answer':'D','reason':'Had the curtain repaired is the causative have+object+past-participle construction.'},
 'CLD-SAT-RW-000199':{'answer':'A','reason':'The archaeologist, not proposal/date/city, performed the study in the introductory modifier.'},
 'CLD-SAT-RW-000005':{'answer':'B','reason':'Two independent clauses require semicolon; the other options create run-on/comma-splice or a malformed relative clause.'},
 'PP-VERBAL-20261022-F-028':{'answer':'B','reason':'Each requires singular bears.'},
 'PP-VERBAL-20261023-M-013':{'answer':'C','reason':'Shift from older-initiated to youngest-initiated interruptions directly supports increased control.'},
 'CLD-SAT-RW-000144':{'answer':'B','reason':'Close the explanatory phrase with the second em dash before is displayed.'},
 'PP-VERBAL-20261022-J-001':{'answer':'C','reason':'A contradiction makes the conclusion logically untenable, not inevitable/impartial/redundant.'},
 'PP-VERBAL-20261023-O-016':{'answer':'D','reason':'Requires that introduces mandative subjunctive state.'},
 'PP-VERBAL-PILOT-003':{'answer':'B','reason':'Collection is singular; together with two notebooks does not make it plural.'},
 'PP-VERBAL-20261022-K-020':{'answer':'C','reason':'Removing acknowledgments in later chapters weakens the proposed growing recognition of help.'},
 'PP-VERBAL-20261022-A-003':{'answer':'C','reason':'Semicolon before and comma after conjunctive adverb therefore joins two independent clauses.'},
}
for id,ev in fresh.items():
 ev['method']='Targeted substantive re-solve in current screening session; not a separately delegated reviewer; keys were visible for the three historical disputes.'
 ev['matches_exported_key']=ev['answer']==by[id]['key']
 if not ev['matches_exported_key']:flag(id,'FRESH_KEY_DISAGREEMENT',ev['reason'])
flag('CLD-SAT-RW-000100','APPOSITIVE_EDITORIAL_DISPUTE','Current key A is favored by the restrictive context, but the inherited ambiguity dispute remains pending editorial adjudication.')

def satdomain(q):
 d=q['domain'];s=d.lower()
 if d in ['Craft and Structure','Information and Ideas','Standard English Conventions','Expression of Ideas']:return d
 if any(t in s for t in ['words in context','cross-text','text structure','function of a sentence']):return 'Craft and Structure'
 if any(t in s for t in ['transition','rhetorical synthesis']):return 'Expression of Ideas'
 if any(t in s for t in ['evidence','inference','central idea','logical completion']):return 'Information and Ideas'
 if any(t in s for t in ['boundar','form, structure','subject-verb','pronoun','modifier','verb','punctuation','possessive']):return 'Standard English Conventions'
 return 'unmapped'
for q in rows:
 id=q['id'];ls=issues.get(id,[])
 if any(x['severity']=='exclude' for x in ls):status='excluded_or_reserved_duplicate'
 elif any(x['severity']=='hold' for x in ls):status='hold_for_revision_or_adjudication'
 else:status='retained_draft_pending_full_editorial_review'
 q['screening']={'disposition':status,'findings':ls,'fresh_substantive_review':fresh.get(id),'scope':'Full-inventory structural/evidence/retrieval screen plus documented targeted content review; NOT a new full-bank blind solve or human clearance.'}
 q['rights_status']='pending_documented_review';q['license_cleared']=False;q['human_approved']=False
 if q['exam']=='SAT':q['sat_domain_normalized']=satdomain(q)

counts=[]
for exam,section in [('ACT','Math'),('ACT','English'),('ACT','Reading'),('SAT','Math'),('SAT','Reading and Writing')]:
 sub=[q for q in rows if (q['exam'],q['section'])==(exam,section)];c=collections.Counter(q['screening']['disposition'] for q in sub)
 counts.append({'exam':exam,'section':section,'raw_records':len(sub),'excluded_or_reserved':c['excluded_or_reserved_duplicate'],'held':c['hold_for_revision_or_adjudication'],'retained_drafts':c['retained_draft_pending_full_editorial_review']})
stats={'raw_total':len(rows),'by_type':counts,'source_counts':dict(collections.Counter(q['source'] for q in rows)),'dispositions':dict(collections.Counter(q['screening']['disposition'] for q in rows)),'all_findings':dict(collections.Counter(i['code'] for ls in issues.values() for i in ls)),'retrieval_pairs_reviewed':len(decisions),'producer_lexical_pairs':53,'new_retrieval_pairs':48,'math_scripts_rerun':774,'math_script_matches':774,'targeted_new_content_reviews':len(fresh),'sat_domain_counts_raw':dict(collections.Counter(q.get('sat_domain_normalized') for q in rows if q['exam']=='SAT')),'sat_domain_counts_retained':dict(collections.Counter(q.get('sat_domain_normalized') for q in rows if q['exam']=='SAT' and q['screening']['disposition'].startswith('retained'))),'human_approved':0,'full_new_blind_resolve_complete':False,'scope_limitations':['All 3,345 records received structural, source-status and review-evidence screening.','All 774 Claude Math author scripts were rerun successfully; those scripts embed authored numbers and are not independent current-stem derivations.','95 unique retrieved/producer-flagged pairs were substantively compared; retrieval cannot establish absence of other concept repeats.','Targeted new substantive reviews cover recorded items only; most records have not had a new independent content solve in this session.','1,191 ChatGPT records lack matching current-version external AI PASS evidence.','No rights clearance, student difficulty calibration, production import or human approval was performed.']}
save('summary.json',stats);save('combined-bank-screened.json',rows);save('screening-findings.json',issues);save('duplicate-adjudications.json',list(decisions.values()));save('targeted-content-review.json',fresh)
save('retained-draft-bank.json',[q for q in rows if q['screening']['disposition'].startswith('retained')]);save('held-and-reserved.json',[q for q in rows if not q['screening']['disposition'].startswith('retained')])
save('blind-review-packet.json',[{k:q[k] for k in ['id','exam','section','passage','passage_id','stem','choices']}|{'underlined_span_number':q['raw'].get('underlined_span_number'),'edit_span':q['raw'].get('edit_span'),'figure':q['raw'].get('figure',q['raw'].get('diagram'))} for q in rows if q['screening']['disposition'].startswith('retained')])
with (P/'item-screening.csv').open('w') as f:
 w=csv.writer(f);w.writerow(['id','exam','section','source','disposition','current_external_ai_pass_recorded','new_targeted_content_review','finding_codes']);w.writerows([q['id'],q['exam'],q['section'],q['source'],q['screening']['disposition'],q['current_external_review'],q['id'] in fresh,';'.join(i['code'] for i in issues.get(q['id'],[]))] for q in rows)

md='# Prep & Price combined question-bank screening\n\n'
md+='## Result and scope\n\nCombined **3,345 records** from six current ChatGPT banks and Claude’s 1,518 live accepted drafts. This completes the inventory, structural, existing-evidence, selected duplicate and targeted-content screening described below. **It is not complete item-by-item independent editorial/answer validation. No record is newly human-approved or cleared for production.**\n\n'
md+='| Type | Raw records | Excluded/reserved | Held | Retained drafts |\n|---|---:|---:|---:|---:|\n'
for x in counts:md+=f'| {x["exam"]} {x["section"]} | {x["raw_records"]:,} | {x["excluded_or_reserved"]} | {x["held"]} | {x["retained_drafts"]:,} |\n'
md+='\nRetained means no blocking defect was identified by this screen; it does **not** mean all answers, distractors, factual claims or conceptual originality have been independently cleared. All original records are preserved, including holds/reserves. Claude’s 110 quarantined/history records remain a separate archive and are not added again to the 3,345 candidate count.\n\n'
md+='## What was checked\n\n- Source JSON, unique IDs, four distinct choice texts, key membership, explanations, passage presence/consistency, known edit-span targets and offsets. No ID collisions, exact full student-facing duplicates or conflicting shared-passage text were found under the documented rules.\n- Claude package: all 722 listed file checksums matched. Full/blind/key coverage is verified in package integrity results.\n- Reran all 774 Claude Math computations successfully against exported choices. These are author-written checks, not a new independent solution of every current stem.\n- Reconciled current-version external AI PASS evidence. Existing self-review is not represented as independent review.\n- Compared 48 new retrieval pairs plus the producer’s 53 lexical flags (95 unique pairs), preserving distinct English targets and mathematical operations. Fourteen new redundant math variants are reserved; one is essentially the same ordering question with the exact same three powers. Ten source records were already excluded/quarantined.\n- Performed '+str(len(fresh))+' targeted substantive reviews, including all 14 SAT questions labeled hard and the three disputed keys. See individual reasoning in targeted-content-review.json. This is a targeted sample, not a random accuracy estimate or full-bank blind solve.\n\n'
md+='## Findings that affect use\n\n- **Five SAT questions have no valid literal insertion**: CLD-SAT-RW-000011, 000034, 000043, 000058, 000230. Their choices repeat the word already before the blank. Held with a proposed repair; original source content remains untouched.\n- **One SAT answer choice is empty** (PP-VERBAL-20261022-B-003). The intended choice means no punctuation; the comma key is correct, but the empty label needs an explicit display representation before delivery. Held.\n- **69 current records explicitly await fresh review after revision**; their previous pass is not a pass for the current wording. **16 Math records also carry an ACT-blueprint hold**; these categories overlap.\n- Claude Math 000130 (-40 degrees) and 000136 (residual +7) were freshly confirmed. SAT 000100’s restrictive-title answer A is favored but remains on editorial hold because of the unresolved appositive dispute.\n- 94 SAT texts are below the official published 25-word lower bound. They may be useful drills, but should not automatically be counted as faithful full-exam items. One SAT underline reference needs renderer support; its named target is retained in source.\n- Rights remain pending. The producer’s original-owned label is not evidence of clearance. No difficulty is student calibrated.\n\n'
md+='## What to create next\n\nThese are product-planning targets, not official requirements:\n\n1. **SAT Math first:** zero dedicated SAT Math questions are present. Build an initial 500 screened items, then expand to 1,000. Use approximately 35% Algebra, 35% Advanced Math, 15% Problem-Solving/Data Analysis and 15% Geometry/Trigonometry; include student-produced responses and calculator-aware solution paths. ACT Math overlap may support reuse only after SAT-specific mapping, re-review and deduplication; do not double-count it as existing SAT coverage.\n2. **SAT Reading and Writing:** aim for 1,000 retained, reviewed items, adding roughly 430 beyond the current retained pool. Prioritize demanding inference, cross-text reasoning, evidence/data interpretation, rhetorical synthesis and plausible distractors. Only 14 of the 578 raw records currently carry a hard estimate, and nine of those are Claude’s AI-rater labels; these are estimates, not calibration.\n3. **ACT English and Reading:** build toward approximately 1,000 reviewed items in each, favoring broader skills, varied passages, appropriate passage sets, less obvious distractors and stronger upper-difficulty coverage. More easy near-variants are lower priority. Claude’s Reading texts are all below 600 words; other streams include longer texts. Length alone does not establish quality or a fixed requirement for every enhanced-ACT passage.\n4. **ACT Math:** pause bulk expansion until existing revisions, suitability holds and concept repeats are addressed. Its volume is already much larger than any other section.\n5. ACT Science has no dedicated bank in these inputs. Address separately only if optional Science preparation is part of launch scope.\n\n'
md+='## Official specifications consulted\n\n- https://satsuite.collegeboard.org/k12-educators/about/alignment/math\n- https://satsuite.collegeboard.org/k12-educators/about/alignment/reading\n- https://satsuite.collegeboard.org/sat/whats-on-the-test/reading-writing\n- https://www.act.org/content/act/en/products-and-services/the-act/test-preparation/act-exam-sections-and-structure.html\n\n'
md+='## Remaining quality gate\n\nA fresh blind content review of every current retained item is still required to claim complete answer-quality screening, particularly the records carrying only author self-review. Use blind-review-packet.json and require item-level answers, ambiguity/distractor findings and version-bound evidence. Review passage sets together, examine lower-similarity concept repeats, verify factual/provenance concerns, and pilot representative items with students before treating difficulty or score predictions as measured. **Do not interpret the retained draft count as a launch-approved count.**\n'
(P/'quality-screening-report.md').write_text(md)
print(json.dumps(stats,indent=2))
