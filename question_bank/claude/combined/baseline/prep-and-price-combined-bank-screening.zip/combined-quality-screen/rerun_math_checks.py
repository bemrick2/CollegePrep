import pathlib,json,importlib.util,sys,ast,signal,time,contextlib
ROOT=pathlib.Path('/workspace/scratch/ba24631dbeef');CL=ROOT/'claude_export/prep-and-price-claude-complete-export';D=CL/'source/checks/act_math';sys.path.insert(0,str(D))
qs=json.loads((CL/'questions-full.json').read_text())['questions'];qs=[q for q in qs if q['section']=='Math']
cache={};results=[]
class Timeout(Exception):pass
def timeout(*a):raise Timeout()
signal.signal(signal.SIGALRM,timeout)
for q in qs:
 n=q['source']['batch'];p=D/f'batch_{n:03d}.py'
 try:
  if n not in cache:
   tree=ast.parse(p.read_text())
   allowed={'math','os','sys','re','fractions','itertools','statistics','random','decimal','_util'}
   for node in ast.walk(tree):
    if isinstance(node,ast.Import) and any(a.name not in allowed for a in node.names):raise RuntimeError('unapproved import')
    if isinstance(node,ast.ImportFrom) and node.module not in allowed:raise RuntimeError('unapproved import')
    if isinstance(node,ast.Call) and isinstance(node.func,ast.Name) and node.func.id in ['open','exec','compile','__import__']:raise RuntimeError('unsafe call')
    if isinstance(node,ast.Call) and isinstance(node.func,ast.Attribute) and isinstance(node.func.value,ast.Name) and node.func.value.id=='os' and node.func.attr not in ['path']:raise RuntimeError('unsafe OS call')
   spec=importlib.util.spec_from_file_location(f'check_{n}',p);mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod);cache[n]=mod
  signal.alarm(5);answer=cache[n].CHECKS[q['source']['draft_candidate']](dict(q['choices']));signal.alarm(0)
  results.append({'id':q['id'],'result':'match' if answer==q['correct_answer'] else 'MISMATCH','computed_answer':answer,'key':q['correct_answer'],'script':str(p.relative_to(CL))})
 except Exception as e:
  signal.alarm(0);results.append({'id':q['id'],'result':'error','error':repr(e),'script':str(p.relative_to(CL))})
(ROOT/'combined-quality-screen/math-recomputation.json').write_text(json.dumps({'scope':'Rerun of author-supplied calculations on current exported choices. This verifies reproducibility, not independent derivation from every current stem.','results':results},indent=2))
from collections import Counter
print(Counter(x['result'] for x in results));print([x for x in results if x['result']!='match'])
