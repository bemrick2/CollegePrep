# Prep & Price combined question-bank screening

## Result and scope

Combined **3,345 records** from six current ChatGPT banks and Claude’s 1,518 live accepted drafts. This completes the inventory, structural, existing-evidence, selected duplicate and targeted-content screening described below. **It is not complete item-by-item independent editorial/answer validation. No record is newly human-approved or cleared for production.**

| Type | Raw records | Excluded/reserved | Held | Retained drafts |
|---|---:|---:|---:|---:|
| ACT Math | 1,654 | 19 | 67 | 1,568 |
| ACT English | 573 | 0 | 0 | 573 |
| ACT Reading | 540 | 4 | 1 | 535 |
| SAT Math | 0 | 0 | 0 | 0 |
| SAT Reading and Writing | 578 | 1 | 8 | 569 |

Retained means no blocking defect was identified by this screen; it does **not** mean all answers, distractors, factual claims or conceptual originality have been independently cleared. All original records are preserved, including holds/reserves. Claude’s 110 quarantined/history records remain a separate archive and are not added again to the 3,345 candidate count.

## What was checked

- Source JSON, unique IDs, four distinct choice texts, key membership, explanations, passage presence/consistency, known edit-span targets and offsets. No ID collisions, exact full student-facing duplicates or conflicting shared-passage text were found under the documented rules.
- Claude package: all 722 listed file checksums matched. Full/blind/key coverage is verified in package integrity results.
- Reran all 774 Claude Math computations successfully against exported choices. These are author-written checks, not a new independent solution of every current stem.
- Reconciled current-version external AI PASS evidence. Existing self-review is not represented as independent review.
- Compared 48 new retrieval pairs plus the producer’s 53 lexical flags (95 unique pairs), preserving distinct English targets and mathematical operations. Fourteen new redundant math variants are reserved; one is essentially the same ordering question with the exact same three powers. Ten source records were already excluded/quarantined.
- Performed 39 targeted substantive reviews, including all 14 SAT questions labeled hard and the three disputed keys. See individual reasoning in targeted-content-review.json. This is a targeted sample, not a random accuracy estimate or full-bank blind solve.

## Findings that affect use

- **Five SAT questions have no valid literal insertion**: CLD-SAT-RW-000011, 000034, 000043, 000058, 000230. Their choices repeat the word already before the blank. Held with a proposed repair; original source content remains untouched.
- **One SAT answer choice is empty** (PP-VERBAL-20261022-B-003). The intended choice means no punctuation; the comma key is correct, but the empty label needs an explicit display representation before delivery. Held.
- **69 current records explicitly await fresh review after revision**; their previous pass is not a pass for the current wording. **16 Math records also carry an ACT-blueprint hold**; these categories overlap.
- Claude Math 000130 (-40 degrees) and 000136 (residual +7) were freshly confirmed. SAT 000100’s restrictive-title answer A is favored but remains on editorial hold because of the unresolved appositive dispute.
- 94 SAT texts are below the official published 25-word lower bound. They may be useful drills, but should not automatically be counted as faithful full-exam items. One SAT underline reference needs renderer support; its named target is retained in source.
- Rights remain pending. The producer’s original-owned label is not evidence of clearance. No difficulty is student calibrated.

## What to create next

These are product-planning targets, not official requirements:

1. **SAT Math first:** zero dedicated SAT Math questions are present. Build an initial 500 screened items, then expand to 1,000. Use approximately 35% Algebra, 35% Advanced Math, 15% Problem-Solving/Data Analysis and 15% Geometry/Trigonometry; include student-produced responses and calculator-aware solution paths. ACT Math overlap may support reuse only after SAT-specific mapping, re-review and deduplication; do not double-count it as existing SAT coverage.
2. **SAT Reading and Writing:** aim for 1,000 retained, reviewed items, adding roughly 430 beyond the current retained pool. Prioritize demanding inference, cross-text reasoning, evidence/data interpretation, rhetorical synthesis and plausible distractors. Only 14 of the 578 raw records currently carry a hard estimate, and nine of those are Claude’s AI-rater labels; these are estimates, not calibration.
3. **ACT English and Reading:** build toward approximately 1,000 reviewed items in each, favoring broader skills, varied passages, appropriate passage sets, less obvious distractors and stronger upper-difficulty coverage. More easy near-variants are lower priority. Claude’s Reading texts are all below 600 words; other streams include longer texts. Length alone does not establish quality or a fixed requirement for every enhanced-ACT passage.
4. **ACT Math:** pause bulk expansion until existing revisions, suitability holds and concept repeats are addressed. Its volume is already much larger than any other section.
5. ACT Science has no dedicated bank in these inputs. Address separately only if optional Science preparation is part of launch scope.

## Official specifications consulted

- https://satsuite.collegeboard.org/k12-educators/about/alignment/math
- https://satsuite.collegeboard.org/k12-educators/about/alignment/reading
- https://satsuite.collegeboard.org/sat/whats-on-the-test/reading-writing
- https://www.act.org/content/act/en/products-and-services/the-act/test-preparation/act-exam-sections-and-structure.html

## Remaining quality gate

A fresh blind content review of every current retained item is still required to claim complete answer-quality screening, particularly the records carrying only author self-review. Use blind-review-packet.json and require item-level answers, ambiguity/distractor findings and version-bound evidence. Review passage sets together, examine lower-similarity concept repeats, verify factual/provenance concerns, and pilot representative items with students before treating difficulty or score predictions as measured. **Do not interpret the retained draft count as a launch-approved count.**
