import json, pathlib, re, hashlib, collections, unicodedata, ast, importlib.util, sys, csv
from fractions import Fraction
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

ROOT=pathlib.Path('/workspace/scratch/ba24631dbeef')
CL=ROOT/'claude_export/prep-and-price-claude-complete-export'
OUT=ROOT/'combined-quality-screen';OUT.mkdir(exist_ok=True)
def read(p):return json.loads(p.read_text())
def save(n,v):(OUT/n).write_text(json.dumps(v,ensure_ascii=False,indent=2))
def norm(t):
 t=unicodedata.normalize('NFKC',str(t)).lower().replace('−','-').replace('’',"'")
 return re.sub(r'\s+',' ',t).strip()
def words(t):return re.findall(r"\b[\w'-]+\b",t)
rows=[];sources=[]
for p in sorted((ROOT/'banks').glob('*.json')):
 d=read(p);qs=d if isinstance(d,list) else d['questions']
 sources.append({'file':p.name,'count':len(qs),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'version':__import__('os').getxattr(p,'user.library-file-version').decode()})
 for q in qs:
  rows.append({'id':q['id'],'exam':q.get('exam','ACT'),'section':q['section'],'stem':q['question_stem'],'choices':q['options'],'key':q.get('correct_answer'),'passage':q.get('context_or_passage',''),'passage_id':q.get('passage_id'),'source_bank':p.name,'source':'ChatGPT','raw':q})
for q in read(CL/'questions-full.json')['questions']:
 rows.append({'id':q['id'],'exam':q['exam'],'section':q['section'],'stem':q['stem'],'choices':q['choices'],'key':q['correct_answer'],'passage':(q.get('passage') or {}).get('text',''),'passage_id':q.get('passage_id'),'source_bank':q['source']['bank_file'],'source':'Claude','raw':q})
sources.append({'file':'prep-and-price-claude-complete-export.zip','count':1518,'sha256':hashlib.sha256((ROOT/'upload/prep-and-price-claude-complete-export.zip').read_bytes()).hexdigest()})
ids=collections.Counter(r['id'] for r in rows);issues=collections.defaultdict(list)
def flag(id,code,detail,severity='hold'):issues[id].append({'code':code,'detail':detail,'severity':severity})
reviews={q['id']:q for q in read(CL/'answer-key-and-review.json')['items']}
for r in rows:
 q=r['raw'];id=r['id'];opts=r['choices'];status=str(q.get('review_status',''))
 if ids[id]>1:flag(id,'ID_COLLISION','Question identifier not unique')
 if not r['stem'].strip():flag(id,'EMPTY_STEM','No stem')
 if not isinstance(opts,dict) or set(opts)!=set('ABCD'):flag(id,'CHOICE_STRUCTURE','Expected A/B/C/D')
 if r['key'] not in opts:flag(id,'INVALID_KEY','Key is absent from choices')
 if len({norm(v) for v in opts.values()})!=4:flag(id,'DUPLICATE_CHOICE','Choice texts are not four distinct values')
 if any(not str(v).strip() for v in opts.values()):flag(id,'EMPTY_CHOICE','Empty answer choice')
 if not q.get('explanation'):flag(id,'MISSING_EXPLANATION','No teaching explanation')
 if r['section']!='Math' and not r['passage'].strip():flag(id,'MISSING_PASSAGE','No passage/context')
 if any(s in status.lower() for s in ['quarantined','excluded']):flag(id,'PREEXISTING_EXCLUSION',status,'exclude')
 if 'pending_fresh_review' in status:flag(id,'REVISED_REVIEW_PENDING','Latest content explicitly awaits fresh review')
 ext=q.get('external_ai_reviews',[])
 r['current_external_review']=False
 for ev in ext:
  f=ev.get('finding',{});version=ev.get('reviewed_content_version')
  if version==q.get('content_version',1) and f.get('verdict')=='PASS' and not f.get('unresolved',False):r['current_external_review']=True
  if version==q.get('content_version',1) and (f.get('unresolved') or f.get('verdict') in ['FAIL','REVISE','REJECT']):flag(id,'EXTERNAL_REVIEW_FINDING',json.dumps(f,ensure_ascii=False))
 if r['source']=='Claude':
  ev=reviews[id]['review'];solvers=[x for x in ev.get('separate_blind_solvers',[]) if x.get('round')=='final']
  r['current_external_review']=bool(solvers) and all(x.get('answer')==r['key'] for x in solvers)
  if not r['current_external_review']:flag(id,'BLIND_REVIEW_ALIGNMENT','Final recorded AI blind solve absent or mismatched')
  quote=q.get('evidence_quote')
  plain_passage=re.sub(r'\{\{\d+\|(.*?)\}\}',r'\1',r['passage'],flags=re.S)
  if quote and norm(quote) not in norm(plain_passage):flag(id,'EVIDENCE_QUOTE_MISMATCH','Recorded quotation not found after removing edit-span markup','warning')
  conflicts=[x for x in ev.get('whole_bank_ai_raters',[]) if x.get('answer') and x['answer']!=r['key']]
  if conflicts:flag(id,'HISTORICAL_KEY_DISPUTE',json.dumps(conflicts,ensure_ascii=False),'warning')
 if r['section']=='English':
  if r['source']=='Claude':
   n=q.get('underlined_span_number')
   if n is not None and not re.search(r'\{\{'+str(n)+r'\|.*?\}\}',r['passage'],re.S):flag(id,'EDIT_TARGET_MISSING',f'Span {n} absent')
  span=q.get('edit_span') or {}
  if not isinstance(span,dict):span={'text':span}
  text=span.get('original',span.get('text'))
  if text and text not in r['passage']:flag(id,'EDIT_TARGET_MISSING','Original edit text absent from passage')
  if 'start_in_marked_passage' in span:
   start=span['start_in_marked_passage'];end=span['end_exclusive_in_marked_passage']
   if r['passage'][start:end]!=span.get('original'):flag(id,'EDIT_OFFSETS_MISMATCH','Stored codepoint span does not equal original text')
 # SAT boundary issue is a representation warning, not automatic content rejection.
 if r['exam']=='SAT' and re.search(r'underlined',r['stem'],re.I) and not any(m in r['passage'] for m in ['<u>','__','{{','[U']):flag(id,'SAT_UNDERLINE_RENDERING','Stem refers to underlining; renderer must reproduce the named target','warning')
 r['word_count']=len(words(r['passage']))
 r['difficulty']=q.get('difficulty',q.get('difficulty_estimate',q.get('provisional_difficulty',q.get('estimated_difficulty','unrecorded'))))
 if isinstance(r['difficulty'],dict):r['difficulty']=r['difficulty'].get('ai_calibrated_label','unrecorded')
 r['domain']=q.get('category',q.get('reporting_category',q.get('skill','unmapped')))

# Full-passage consistency across every use of the same passage ID.
passages=collections.defaultdict(list)
for r in rows:
 if r['passage_id']:passages[(r['source'],r['passage_id'])].append(r)
for k,group in passages.items():
 if len({norm(r['passage']) for r in group})>1:
  for r in group:flag(r['id'],'PASSAGE_VERSION_CONFLICT',f'Shared passage {k[1]} has inconsistent current text')

# Exact student-facing repeats, ignoring choice ordering. Numbers are retained.
fingerprints=collections.defaultdict(list)
for r in rows:
 fp=(r['exam'],r['section'],norm(r['passage']),norm(r['stem']),tuple(sorted(norm(v) for v in r['choices'].values())))
 fingerprints[fp].append(r)
exact_groups=[]
for group in fingerprints.values():
 if len(group)>1:
  keeper=sorted(group,key=lambda x:(not x['current_external_review'],x['id']))[0]
  exact_groups.append({'keep':keeper['id'],'duplicates':[x['id'] for x in group if x is not keeper]})
  for r in group:
   if r is not keeper:flag(r['id'],'EXACT_DUPLICATE',f'Same student-facing item as {keeper["id"]}','exclude')

# Broad numeric-template and semantic-retrieval screening. Similarity is not a duplicate verdict.
pairs=[]
for section in sorted({(r['exam'],r['section']) for r in rows}):
 subset=[r for r in rows if (r['exam'],r['section'])==section and not any(i['severity']=='exclude' for i in issues[r['id']])]
 texts=[];templates=[];pn=[];qsets=[]
 for r in subset:
  t=r['stem']+' '+' '.join(r['choices'].values())
  if section[1]!='Math':t=r['passage']+' '+t
  texts.append(norm(t));templates.append(re.sub(r'\d+(?:\.\d+)?',' NUM ',norm(t)))
  pn.append(norm(r['passage']));qsets.append(set(words(norm(r['stem']+' '+' '.join(r['choices'].values())))))
 if len(subset)<2:continue
 token_pattern=r'\d+(?:\.\d+)?|[a-z_]+|[^\w\s]'
 v=TfidfVectorizer(ngram_range=(1,2),min_df=1,sublinear_tf=True,token_pattern=token_pattern);x=v.fit_transform(texts);s=cosine_similarity(x)
 tv=TfidfVectorizer(ngram_range=(1,2),sublinear_tf=True,token_pattern=token_pattern);tx=tv.fit_transform(templates);ts=cosine_similarity(tx)
 for i in range(len(subset)):
  for j in range(i+1,len(subset)):
   a,b=subset[i],subset[j]
   # Shared-passage questions legitimately have high full-text similarity. Compare question+choices separately.
   if section[1]!='Math' and pn[i]==pn[j]:
    aa=qsets[i];bb=qsets[j]
    score=len(aa&bb)/len(aa|bb) if aa|bb else 0
    threshold=.8;type='same_passage_question_overlap'
   else:score=max(float(s[i,j]),float(ts[i,j]));threshold=.80 if section[1]=='Math' else .85;type='numeric_template_or_text_similarity'
   if score>=threshold:
    pairs.append({'a':a['id'],'b':b['id'],'score':round(score,4),'section':' '.join(section),'method':type,'status':'pending_substantive_adjudication'})
pairs.sort(key=lambda p:-p['score'])
save('source-inventory.json',sources);save('combined-bank-preserved.json',rows);save('issues-initial.json',issues);save('exact-duplicates.json',exact_groups);save('similarity-candidates.json',pairs)
print(json.dumps({'raw_total':len(rows),'counts':dict(collections.Counter(r['exam']+' '+r['section'] for r in rows)),'sources':sources,'flags':dict(collections.Counter(i['code'] for arr in issues.values() for i in arr)),'exact_duplicate_groups':len(exact_groups),'similarity_pairs':len(pairs)},indent=2))
byid={r['id']:r for r in rows}
with (OUT/'candidate-pairs-review.txt').open('w') as f:
 for p in pairs:
  f.write(json.dumps(p)+'\n')
  for id in [p['a'],p['b']]:
   r=byid[id];f.write(id+' | '+r['stem']+' | '+json.dumps(r['choices'],ensure_ascii=False)+'\n')
with (OUT/'screen-initial.csv').open('w') as f:
 w=csv.writer(f);w.writerow(['id','exam','section','source','review_evidence','issues']);w.writerows([r['id'],r['exam'],r['section'],r['source'],r['current_external_review'],';'.join(i['code'] for i in issues[r['id']])] for r in rows)
